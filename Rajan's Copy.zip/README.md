"# CPI310"  git init git add README.md git commit -m "first commit" git remote add origin https://github.com/mtcrowley/CPI310.git git push -u origin master
"# CPI310" 
